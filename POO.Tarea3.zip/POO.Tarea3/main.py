# main.py es la VISTA: lo único que habla con el usuario (input/print).
# No valida ni guarda nada: le pide todo a los controladores
# (views.py y views_academico.py) y solo muestra lo que ellos responden.
from shared.herramientas import (
    VERDE, MAGENTA, CIAN, AMARILLO, ROJO, TENUE, NEGRITA,
    pintar, limpiar_pantalla, banner, imprimir_titulo, imprimir_exito,
    imprimir_error, imprimir_info, imprimir_menu, pedir_opcion, pedir,
    barra, linea, confirmar,
)
from views import ClienteController, ProductoController, VentaController
from views_academico import armar_academico


class Menu:

    def __init__(self):
        # UN solo controlador de cada tipo; ventas y matrículas reciben los MISMOS
        self.clientes = ClienteController()
        self.productos = ProductoController()
        self.ventas = VentaController(self.clientes, self.productos)
        (self.estudiantes, self.docentes,
         self.materias, self.matriculas) = armar_academico()

        # El menú principal se dibuja recorriendo esta lista (es dinámico):
        # para agregar un sistema nuevo basta con agregar un diccionario.
        self.sistemas = [
            {"clave": "1", "nombre": "Sistema de Ventas", "icono": "🛒", "color": VERDE,
             "modulos": [self.clientes, self.productos, self.ventas]},
            {"clave": "2", "nombre": "Sistema Académico", "icono": "🎓", "color": MAGENTA,
             "modulos": [self.estudiantes, self.docentes, self.materias, self.matriculas]},
        ]

    # ---------- ayudas ----------
    def pausa(self):
        input(pintar("\n  Presione Enter para continuar...", TENUE))

    def pedir_entero(self, texto):
        try:
            return int(input(pintar(f"  {texto}", CIAN)))
        except ValueError:
            return None

    def mostrar_resultado(self, exito, mensaje):
        if exito:
            imprimir_exito(mensaje)
        else:
            imprimir_error(mensaje)

    def plural(self, controlador):
        return controlador.nombre.capitalize() + "s"

    # ---------- menú principal ----------
    def ejecutar(self):
        while True:
            limpiar_pantalla()
            banner("SISTEMA INTEGRAL", "Ventas  ·  Académico")

            opciones = []
            for s in self.sistemas:
                total = sum(len(m.leer()) for m in s["modulos"])
                opciones.append((s["clave"], f'{s["icono"]}  {s["nombre"]}',
                                 f"{total} registros"))
            opciones.append(("0", "Salir", ""))
            imprimir_menu(opciones)

            opcion = pedir_opcion()
            elegido = next((s for s in self.sistemas if s["clave"] == opcion), None)
            if elegido:
                self.menu_sistema(elegido)
            elif opcion == "0":
                imprimir_info("¡Hasta luego! 👋")
                break
            else:
                imprimir_error("Opción no válida")
                self.pausa()

    # ---------- menú de cada sistema ----------
    def menu_sistema(self, sistema):
        color = sistema["color"]
        es_academico = sistema["modulos"][0] is self.estudiantes
        while True:
            limpiar_pantalla()
            imprimir_titulo(sistema["nombre"].upper(), color)   # sin emoji: ocupa 2 columnas y descuadra el recuadro

            opciones = []
            for i, modulo in enumerate(sistema["modulos"], start=1):
                opciones.append((str(i), self.plural(modulo), f"{len(modulo.leer())} registros"))
            if es_academico:
                opciones.append((str(len(sistema["modulos"]) + 1), "Reportes", ""))
            opciones.append(("0", "Volver al menú principal", ""))
            imprimir_menu(opciones, color)

            opcion = pedir_opcion()
            if opcion == "0":
                break
            if opcion.isdigit() and 1 <= int(opcion) <= len(sistema["modulos"]):
                self.menu_crud(sistema["modulos"][int(opcion) - 1], color)
            elif es_academico and opcion == str(len(sistema["modulos"]) + 1):
                self.menu_reportes(color)
            else:
                imprimir_error("Opción no válida")
                self.pausa()

    # ---------- menú de cada controlador ----------
    # El mismo menú sirve para todos, porque todos los controladores
    # tienen los mismos métodos. Solo cambian las opciones extra.
    def extras_de(self, controlador):
        if controlador is self.ventas:
            return [("Ver factura", self.ver_factura)]
        if controlador is self.matriculas:
            return [("Agregar nota", self.agregar_nota), ("Ver boletín", self.ver_boletin)]
        return []

    def menu_crud(self, controlador, color):
        extras = self.extras_de(controlador)
        while True:
            limpiar_pantalla()
            imprimir_titulo(self.plural(controlador).upper(), color)

            opciones = [
                ("1", f"Crear {controlador.nombre}", ""),
                ("2", "Ver todos", f"{len(controlador.leer())} registros"),
                ("3", "Buscar", ""),
                ("4", "Ver por id", ""),
                ("5", "Actualizar", ""),
                ("6", "Eliminar", ""),
            ]
            for i, (texto, _) in enumerate(extras, start=7):
                opciones.append((str(i), texto, ""))
            opciones.append(("0", "Volver", ""))
            imprimir_menu(opciones, color)

            opcion = pedir_opcion()
            if opcion == "1":
                if controlador is self.ventas:
                    self.crear_venta()
                elif controlador is self.matriculas:
                    self.crear_matricula()
                else:
                    self.crear(controlador)
            elif opcion == "2":
                self.ver_todos(controlador, color)
            elif opcion == "3":
                self.buscar(controlador, color)
            elif opcion == "4":
                self.ver_por_id(controlador, color)
            elif opcion == "5":
                self.actualizar(controlador, color)
            elif opcion == "6":
                self.eliminar(controlador, color)
            elif opcion.isdigit() and 7 <= int(opcion) < 7 + len(extras):
                extras[int(opcion) - 7][1]()
            elif opcion == "0":
                break
            else:
                imprimir_error("Opción no válida")
                self.pausa()

    # ---------- operaciones genéricas ----------
    def crear(self, controlador):
        imprimir_titulo(f"CREAR {controlador.nombre.upper()}", VERDE)
        if controlador is self.materias:
            imprimir_info("Docentes disponibles (deje el docente en blanco si aún no tiene):")
            for d in self.docentes.leer():
                print(f"    {d}")
            print()

        datos = {}
        for campo in controlador.campos:
            datos[campo] = input(pintar(f"  {campo.capitalize()}: ", CIAN))

        exito, mensaje = controlador.crear(datos)
        self.mostrar_resultado(exito, mensaje)
        self.pausa()

    def ver_todos(self, controlador, color):
        imprimir_titulo(self.plural(controlador).upper(), color)
        lista = controlador.leer()
        if len(lista) == 0:
            imprimir_info("No hay registros todavía.")
        else:
            for objeto in lista:
                print(f"  {objeto}")
            linea()
            imprimir_info(f"Total: {len(lista)}")
        self.pausa()

    def buscar(self, controlador, color):
        imprimir_titulo(f"BUSCAR {controlador.nombre.upper()}", color)
        texto = input(pintar("  Buscar: ", CIAN))
        encontrados = controlador.buscar(texto)
        if len(encontrados) == 0:
            imprimir_info(f"Sin coincidencias para '{texto}'.")
        else:
            for objeto in encontrados:
                print(f"  {objeto}")
            imprimir_info(f"{len(encontrados)} coincidencia(s)")
        self.pausa()

    def ver_por_id(self, controlador, color):
        imprimir_titulo(f"VER {controlador.nombre.upper()}", color)
        id_registro = self.pedir_entero("Id: ")
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
        else:
            for clave, valor in objeto.a_diccionario().items():
                if isinstance(valor, list):          # partes de una composición
                    print(f"  {pintar(clave.capitalize() + ':', NEGRITA)}")
                    for parte in valor:
                        print(f"      · {parte}")
                else:
                    print(f"  {pintar(clave.capitalize() + ':', NEGRITA)} {valor}")
        self.pausa()

    def actualizar(self, controlador, color):
        imprimir_titulo(f"ACTUALIZAR {controlador.nombre.upper()}", color)
        if controlador is self.ventas:
            imprimir_error("Las ventas registradas no se pueden modificar")
            self.pausa()
            return

        id_registro = self.pedir_entero("Id: ")
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
            self.pausa()
            return

        imprimir_info(f"Editando: {objeto.etiqueta()}")
        print("  Deje en blanco lo que no quiera cambiar.\n")
        cambios = {}
        for campo in controlador.campos:
            actual = getattr(objeto, campo)
            nuevo = input(pintar(f"  {campo.capitalize()} [{actual}]: ", CIAN)).strip()
            if nuevo != "":
                cambios[campo] = nuevo

        exito, mensaje = controlador.actualizar(id_registro, cambios)
        self.mostrar_resultado(exito, mensaje)
        self.pausa()

    def eliminar(self, controlador, color):
        imprimir_titulo(f"ELIMINAR {controlador.nombre.upper()}", ROJO)
        id_registro = self.pedir_entero("Id: ")
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error("No encontrado")
            self.pausa()
            return

        imprimir_info(f"Se eliminará: {objeto.etiqueta()}")
        if confirmar("¿Confirma?"):
            exito, mensaje = controlador.eliminar(id_registro)
            self.mostrar_resultado(exito, mensaje)
        else:
            imprimir_info("Operación cancelada")
        self.pausa()

    # ---------- solo para ventas ----------
    def crear_venta(self):
        imprimir_titulo("REGISTRAR VENTA", VERDE)
        imprimir_info("Clientes:")
        for c in self.clientes.leer():
            print(f"    {c}")
        cliente_id = self.pedir_entero("\n  Id del cliente: ")
        if cliente_id is None:
            imprimir_error("El id debe ser un número")
            self.pausa()
            return

        imprimir_info("Productos disponibles:")
        for p in self.productos.leer():
            print(f"    {p}")

        items = []      # se piden productos hasta que el usuario escriba 0
        while True:
            producto_id = self.pedir_entero("\n  Id del producto (0 para terminar): ")
            if producto_id is None or producto_id == 0:
                break
            cantidad = self.pedir_entero("  Cantidad: ")
            if cantidad is None or cantidad <= 0:
                imprimir_error("Cantidad inválida")
                continue
            items.append({"producto_id": producto_id, "cantidad": cantidad})

        exito, mensaje = self.ventas.crear({"cliente_id": cliente_id, "items": items})
        self.mostrar_resultado(exito, mensaje)
        self.pausa()

    def ver_factura(self):
        imprimir_titulo("FACTURA", VERDE)
        id_venta = self.pedir_entero("Id de la venta: ")
        texto = self.ventas.factura(id_venta)
        if texto is None:
            imprimir_error("No existe esa venta")
        else:
            print()
            print(texto)
        self.pausa()

    # ---------- solo para matrículas ----------
    def crear_matricula(self):
        imprimir_titulo("NUEVA MATRÍCULA", MAGENTA)
        imprimir_info("Estudiantes:")
        for e in self.estudiantes.leer():
            print(f"    {e}")
        imprimir_info("Materias:")
        for m in self.materias.leer():
            print(f"    {m}")

        datos = {
            "estudiante_id": input(pintar("\n  Id del estudiante: ", CIAN)),
            "materia_id": input(pintar("  Id de la materia: ", CIAN)),
            "periodo": input(pintar("  Periodo (ej. 2026-1, Enter = 2026-1): ", CIAN)),
        }
        exito, mensaje = self.matriculas.crear(datos)
        self.mostrar_resultado(exito, mensaje)
        self.pausa()

    def agregar_nota(self):
        imprimir_titulo("AGREGAR NOTA", MAGENTA)
        for m in self.matriculas.leer():
            print(f"    {m}")
        matricula_id = self.pedir_entero("\n  Id de la matrícula: ")
        if matricula_id is None:
            imprimir_error("El id debe ser un número")
            self.pausa()
            return

        tipo = input(pintar("  Tipo (deber / lección / examen): ", CIAN))
        valor = input(pintar("  Valor (0 a 20): ", CIAN))
        peso = input(pintar("  Peso (Enter = 1): ", CIAN)).strip() or 1

        exito, mensaje = self.matriculas.agregar_nota(matricula_id, tipo, valor, peso)
        self.mostrar_resultado(exito, mensaje)
        self.pausa()

    def ver_boletin(self):
        imprimir_titulo("BOLETÍN", MAGENTA)
        for e in self.estudiantes.leer():
            print(f"    {e}")
        estudiante_id = self.pedir_entero("\n  Id del estudiante: ")
        texto = self.matriculas.boletin(estudiante_id)
        if texto is None:
            imprimir_error("No existe ese estudiante")
        else:
            print()
            print(texto)
        self.pausa()

    # ---------- reportes (polimorfismo: todo se imprime con etiqueta()) ----------
    def menu_reportes(self, color):
        while True:
            limpiar_pantalla()
            imprimir_titulo("REPORTES", color)
            imprimir_menu([
                ("1", "Estudiantes reprobados", ""),
                ("2", "Promedio por materia", ""),
                ("3", "Materias por docente", ""),
                ("0", "Volver", ""),
            ], color)

            opcion = pedir_opcion()
            if opcion == "1":
                self.reporte_reprobados()
            elif opcion == "2":
                self.reporte_promedios()
            elif opcion == "3":
                self.reporte_materias_por_docente()
            elif opcion == "0":
                break
            else:
                imprimir_error("Opción no válida")
                self.pausa()

    def reporte_reprobados(self):
        imprimir_titulo("ESTUDIANTES REPROBADOS", ROJO)
        reprobados = self.matriculas.reprobados()
        if not reprobados:
            imprimir_exito("No hay matrículas reprobadas.")
        for m in reprobados:
            estudiante = self.estudiantes.obtener(m.estudiante_id)
            materia = self.materias.obtener(m.materia_id)
            print(f"  {estudiante.nombre_completo}  ·  {materia.nombre}  ·  "
                  f"{pintar(m.promedio, ROJO, NEGRITA)}")
        self.pausa()

    def reporte_promedios(self):
        imprimir_titulo("PROMEDIO POR MATERIA", CIAN)
        filas = self.matriculas.promedio_por_materia()
        if not filas:
            imprimir_info("Todavía no hay notas registradas.")
        for materia, promedio, cantidad in filas:
            print(f"  {materia.nombre:<28} {barra(promedio, 20)} {promedio:>5}  ({cantidad})")
        self.pausa()

    def reporte_materias_por_docente(self):
        imprimir_titulo("MATERIAS POR DOCENTE", CIAN)
        for docente in self.docentes.leer():
            materias = self.materias.materias_de_docente(docente.id)
            print(f"  {pintar(docente.nombre_completo, NEGRITA)}  ({len(materias)})")
            for m in materias:
                print(f"      · {m.etiqueta()}")
        self.pausa()


# Solo arranca si se ejecuta "python main.py"
if __name__ == "__main__":
    try:
        Menu().ejecutar()
    except KeyboardInterrupt:
        print("\nPrograma interrumpido por el usuario.")
