# Sistema Integral · Ventas y Académico (Python POO)

CRUD en consola con persistencia en JSON y arquitectura por capas.

## Cómo ejecutarlo

```
python main.py
```

Requiere Python 3.8 o superior. No usa librerías externas. Los datos de ejemplo
están en `data/` (si borras esa carpeta, el programa la vuelve a crear vacía).

## Estructura

```
main.py                ← Vista: menús, input y print
models.py              ← ModeloBase, Persona, Cliente, Producto, DetalleVenta, Venta
models_academico.py    ← Estudiante, Docente, Materia, Nota, Matricula
views.py               ← CrudBase (interfaz) + controladores de ventas
views_academico.py     ← controladores académicos (CRUD genérico + reglas)
shared/                ← GestorJSON y herramientas de consola (colores, recuadros)
data/                  ← archivos JSON
docs/                  ← diagramas UML (Mermaid)
```

## Principios aplicados

- **Abstracción:** `ModeloBase` y `CrudBase` son clases abstractas.
- **Encapsulamiento:** atributos privados con propiedades que validan.
- **Herencia:** `Persona` → `Estudiante`, `Docente`, `Cliente`.
- **Polimorfismo:** cada modelo escribe su `etiqueta()` y un solo menú sirve a todos.
- **Composición:** `Venta` ◆ `DetalleVenta`, `Matricula` ◆ `Nota`.
- **Agregación:** la matrícula guarda `estudiante_id` y `materia_id`; la materia guarda `docente_id`.

## Reglas de negocio (académico)

- Carnet de estudiante único y email de docente único.
- Código de materia único y créditos entre 0 y 10.
- No se asigna un docente inexistente.
- No se matricula dos veces al mismo estudiante en la misma materia y periodo.
- Notas de 0 a 20; tipos permitidos: deber, lección, examen. Aprobado desde 14.
