"""Controladores del sistema académico.

Tienen la misma interfaz que los de ventas (views.py): nombre, campos, leer,
buscar, obtener, crear, actualizar, eliminar. Por eso el Menu de main.py
sirve para todos sin cambiar nada.
"""
from models_academico import Estudiante, Docente, Materia, Matricula, Nota
from shared.json_manager import GestorJSON
from views import CrudBase


# =====================================================================
# CONTROLADOR GENÉRICO: el CRUD se escribe UNA sola vez aquí.
# Cada hijo solo dice qué modelo usa y escribe su propio validar().
# =====================================================================
class CrudAcademico(CrudBase):
    MODELO = None
    ARCHIVO = ""
    NOMBRE = ""
    CAMPOS_BUSCABLES = ()

    def __init__(self):
        self.nombre = self.NOMBRE
        self.campos = self.MODELO.CAMPOS
        self.gestor = GestorJSON(self.ARCHIVO)
        # Controladores que dependen de este: (controlador, campo_id, texto)
        self.dependientes = []

        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(self.MODELO.desde_diccionario(datos))

    # ---------- persistencia ----------
    def guardar(self):
        self.gestor.guardar([objeto.a_diccionario() for objeto in self.lista])

    def registros(self):
        """Los datos como diccionarios, útiles para comparar campos."""
        return [objeto.a_diccionario() for objeto in self.lista]

    # ---------- consultas ----------
    def obtener(self, id_registro):
        for objeto in self.lista:
            if objeto.id == id_registro:
                return objeto
        return None

    def existe(self, id_registro):
        return self.obtener(id_registro) is not None

    def leer(self):
        return self.lista

    def buscar(self, texto):
        texto = texto.strip().lower()
        if texto == "":
            return []
        encontrados = []
        for objeto in self.lista:
            datos = objeto.a_diccionario()
            if any(texto in str(datos.get(campo, "")).lower()
                   for campo in self.CAMPOS_BUSCABLES):
                encontrados.append(objeto)
        return encontrados

    def siguiente(self):
        return max((objeto.id for objeto in self.lista), default=0) + 1

    # ---------- reglas (los hijos las sobrescriben) ----------
    def validar(self, datos, id_actual=None):
        """Devuelve un texto con el error, o None si todo está bien."""
        return None

    def faltantes(self, datos):
        return [campo for campo in self.MODELO.OBLIGATORIOS
                if not str(datos.get(campo, "")).strip()]

    # ---------- operaciones ----------
    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        try:
            valores = {campo: datos.get(campo, "") for campo in self.MODELO.CAMPOS}
            objeto = self.MODELO(self.siguiente(), **valores)
        except ValueError as e:
            return False, str(e)

        self.lista.append(objeto)
        self.guardar()
        return True, f"{self.NOMBRE.capitalize()} creado: {objeto.etiqueta()}"

    def actualizar(self, id_registro, datos):
        if not datos:
            return False, "No se indicó ningún cambio"
        objeto = self.obtener(id_registro)
        if objeto is None:
            return False, f"No existe {self.NOMBRE} con id {id_registro}"

        error = self.validar(datos, id_actual=id_registro)
        if error:
            return False, error

        # Se arma un objeto nuevo con los cambios; si algo falla, el viejo queda igual
        try:
            nuevo = self.MODELO.desde_diccionario({**objeto.a_diccionario(), **datos})
        except ValueError as e:
            return False, str(e)

        self.lista[self.lista.index(objeto)] = nuevo
        self.guardar()
        return True, f"{self.NOMBRE.capitalize()} actualizado: {nuevo.etiqueta()}"

    def eliminar(self, id_registro):
        objeto = self.obtener(id_registro)
        if objeto is None:
            return False, f"No existe {self.NOMBRE} con id {id_registro}"

        # Integridad: no se borra algo que otros registros todavía referencian
        for controlador, campo, texto in self.dependientes:
            if any(r[campo] == id_registro for r in controlador.registros()):
                return False, f"No se puede eliminar: tiene {texto} asociadas"

        self.lista.remove(objeto)
        self.guardar()
        return True, f"{self.NOMBRE.capitalize()} eliminado: {objeto.etiqueta()}"


# =====================================================================
# ESTUDIANTES
# =====================================================================
class EstudianteController(CrudAcademico):
    MODELO = Estudiante
    ARCHIVO = "data/estudiantes.json"
    NOMBRE = "estudiante"
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "carnet")

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            faltan = self.faltantes(datos)
            if faltan:
                return f"Faltan campos obligatorios: {', '.join(faltan)}"

        # Regla: el carnet es único
        if str(datos.get("carnet", "")).strip():
            carnet = str(datos["carnet"]).strip().upper()
            usados = {r["carnet"] for r in self.registros() if r["id"] != id_actual}
            if carnet in usados:
                return f"El carnet {carnet} ya está registrado"
        return None


# =====================================================================
# DOCENTES
# =====================================================================
class DocenteController(CrudAcademico):
    MODELO = Docente
    ARCHIVO = "data/docentes.json"
    NOMBRE = "docente"
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "especialidad")

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            faltan = self.faltantes(datos)
            if faltan:
                return f"Faltan campos obligatorios: {', '.join(faltan)}"

        # Regla: el email del docente es único
        if str(datos.get("email", "")).strip():
            email = str(datos["email"]).strip().lower()
            usados = {r["email"] for r in self.registros() if r["id"] != id_actual}
            if email in usados:
                return f"El email {email} ya está registrado"
        return None


# =====================================================================
# MATERIAS (agregación: guarda el id de su docente)
# =====================================================================
class MateriaController(CrudAcademico):
    MODELO = Materia
    ARCHIVO = "data/materias.json"
    NOMBRE = "materia"
    CAMPOS_BUSCABLES = ("nombre", "codigo")

    def __init__(self, docentes):
        super().__init__()
        self.docentes = docentes      # el MISMO controlador que usa el menú

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            faltan = self.faltantes(datos)
            if faltan:
                return f"Faltan campos obligatorios: {', '.join(faltan)}"

        # Regla: el código de la materia es único
        if str(datos.get("codigo", "")).strip():
            codigo = str(datos["codigo"]).strip().upper()
            usados = {r["codigo"] for r in self.registros() if r["id"] != id_actual}
            if codigo in usados:
                return f"El código {codigo} ya está registrado"

        # Regla: los créditos van de 0 a 10
        if str(datos.get("creditos", "")).strip():
            try:
                creditos = int(datos["creditos"])
            except ValueError:
                return "Los créditos deben ser un número entero"
            if not 0 <= creditos <= 10:
                return "Los créditos deben estar entre 0 y 10"

        # Regla: no se asigna un docente que no existe
        docente = str(datos.get("docente_id", "")).strip()
        if docente not in ("", "0", "None"):
            try:
                if not self.docentes.existe(int(docente)):
                    return f"No existe un docente con id {docente}"
            except ValueError:
                return "El id del docente debe ser un número"
        return None

    def asignar_docente(self, materia_id, docente_id):
        if not self.existe(materia_id):
            return False, f"No existe materia con id {materia_id}"
        if not self.docentes.existe(docente_id):
            return False, f"No existe un docente con id {docente_id}"
        return self.actualizar(materia_id, {"docente_id": docente_id})

    def materias_de_docente(self, docente_id):
        return [m for m in self.lista if m.docente_id == docente_id]


# =====================================================================
# MATRÍCULAS (agregación con estudiante y materia, composición con notas)
# =====================================================================
class MatriculaController(CrudAcademico):
    MODELO = Matricula
    ARCHIVO = "data/matriculas.json"
    NOMBRE = "matrícula"
    CAMPOS_BUSCABLES = ("periodo", "estado")

    def __init__(self, estudiantes, materias):
        super().__init__()
        self.estudiantes = estudiantes
        self.materias = materias

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            faltan = self.faltantes(datos)
            if faltan:
                return f"Faltan campos obligatorios: {', '.join(faltan)}"

        actual = self.obtener(id_actual) if id_actual is not None else None
        try:
            estudiante_id = int(datos.get("estudiante_id", actual.estudiante_id if actual else 0))
            materia_id = int(datos.get("materia_id", actual.materia_id if actual else 0))
        except ValueError:
            return "El estudiante y la materia se indican con su id (un número)"
        periodo = str(datos.get("periodo", actual.periodo if actual else "")).strip() or "2026-1"

        # Reglas: el estudiante y la materia deben existir
        if not self.estudiantes.existe(estudiante_id):
            return f"No existe un estudiante con id {estudiante_id}"
        if not self.materias.existe(materia_id):
            return f"No existe una materia con id {materia_id}"

        # Regla: no se matricula dos veces al mismo estudiante en la misma materia y periodo
        for r in self.registros():
            if (r["id"] != id_actual and r["estudiante_id"] == estudiante_id
                    and r["materia_id"] == materia_id and r["periodo"] == periodo):
                return "Ese estudiante ya está matriculado en esa materia y periodo"
        return None

    # ---------- composición: las notas se agregan con su propio método ----------
    def agregar_nota(self, matricula_id, tipo, valor, peso=1):
        matricula = self.obtener(matricula_id)
        if matricula is None:
            return False, f"No existe matrícula con id {matricula_id}"

        try:
            nota = matricula.agregar_nota(tipo, valor, peso)
        except ValueError as e:
            return False, str(e)

        self.guardar()    # sin esto la nota solo vive en RAM y se pierde al cerrar
        return True, (f"Nota agregada: {nota}. "
                      f"Promedio ahora: {matricula.promedio} ({matricula.estado})")

    # ---------- boletín (igual que la factura de ventas) ----------
    def boletin(self, estudiante_id):
        estudiante = self.estudiantes.obtener(estudiante_id)
        if estudiante is None:
            return None

        propias = [m for m in self.lista if m.estudiante_id == estudiante_id]
        lineas = [f"BOLETÍN · {estudiante.nombre_completo} · carnet {estudiante.carnet}",
                  "-" * 56]
        if not propias:
            lineas.append("Sin matrículas registradas.")
            return "\n".join(lineas)

        promedios = []
        for m in propias:
            materia = self.materias.obtener(m.materia_id)
            nombre = materia.nombre if materia else f"Materia {m.materia_id}"
            notas = ", ".join(str(n) for n in m.notas) or "sin notas"
            lineas.append(f"{nombre} ({m.periodo})")
            lineas.append(f"    notas: {notas}")
            lineas.append(f"    promedio: {m.promedio}   estado: {m.estado}")
            if m.notas:
                promedios.append(m.promedio)

        general = round(sum(promedios) / len(promedios), 2) if promedios else 0
        lineas.append("-" * 56)
        lineas.append(f"PROMEDIO GENERAL: {general}")
        return "\n".join(lineas)

    # ---------- reportes ----------
    def reprobados(self):
        return [m for m in self.lista if m.estado == "Reprobado"]

    def promedio_por_materia(self):
        """Lista de (materia, promedio, cantidad de matrículas con notas)."""
        resultado = []
        for materia in self.materias.leer():
            con_notas = [m for m in self.lista
                         if m.materia_id == materia.id and m.notas]
            if con_notas:
                promedio = round(sum(m.promedio for m in con_notas) / len(con_notas), 2)
                resultado.append((materia, promedio, len(con_notas)))
        return resultado


# =====================================================================
# ARMADO: crea UN controlador de cada tipo y los conecta entre sí
# =====================================================================
def armar_academico():
    docentes = DocenteController()
    estudiantes = EstudianteController()
    materias = MateriaController(docentes)
    matriculas = MatriculaController(estudiantes, materias)

    # Integridad referencial: qué impide borrar a cada uno
    docentes.dependientes.append((materias, "docente_id", "materias"))
    estudiantes.dependientes.append((matriculas, "estudiante_id", "matrículas"))
    materias.dependientes.append((matriculas, "materia_id", "matrículas"))
    return estudiantes, docentes, materias, matriculas
