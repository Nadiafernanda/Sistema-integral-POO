"""Herramientas de consola: colores, recuadros y menús.
Todo lo que sea "verse bonito" vive aquí, para que main.py solo decida QUÉ mostrar."""
import os
from datetime import datetime

os.system("")  # activa los colores ANSI en la consola de Windows

# ---------- colores (códigos ANSI) ----------
RESET = "\033[0m"
NEGRITA = "\033[1m"
TENUE = "\033[2m"
ROJO = "\033[91m"
VERDE = "\033[92m"
AMARILLO = "\033[93m"
AZUL = "\033[94m"
MAGENTA = "\033[95m"
CIAN = "\033[96m"
BLANCO = "\033[97m"

ANCHO = 60


def pintar(texto, *estilos):
    """Devuelve el texto envuelto en los estilos pedidos y cerrado con RESET."""
    return "".join(estilos) + str(texto) + RESET


def limpiar_pantalla():
    print("\033[2J\033[H", end="")


# ---------- recuadros ----------
def imprimir_titulo(texto, color=CIAN):
    print()
    print(pintar("╔" + "═" * ANCHO + "╗", color))
    print(pintar("║", color) + pintar(texto.center(ANCHO), NEGRITA, BLANCO) + pintar("║", color))
    print(pintar("╚" + "═" * ANCHO + "╝", color))


def banner(titulo, subtitulo="", color=CIAN):
    """Cabecera grande de la pantalla principal, con fecha y hora actuales."""
    ahora = datetime.now().strftime("%d/%m/%Y  %H:%M")
    print()
    print(pintar("╔" + "═" * ANCHO + "╗", color))
    print(pintar("║", color) + pintar(titulo.center(ANCHO), NEGRITA, BLANCO) + pintar("║", color))
    if subtitulo:
        print(pintar("║", color) + pintar(subtitulo.center(ANCHO), color) + pintar("║", color))
    print(pintar("╠" + "═" * ANCHO + "╣", color))
    print(pintar("║", color) + pintar(ahora.center(ANCHO), TENUE) + pintar("║", color))
    print(pintar("╚" + "═" * ANCHO + "╝", color))


def linea():
    print(pintar("─" * ANCHO, TENUE))


# ---------- mensajes ----------
def imprimir_exito(mensaje):
    print(pintar(f"  ✔ {mensaje}", VERDE))


def imprimir_error(mensaje):
    print(pintar(f"  ✘ {mensaje}", ROJO))


def imprimir_info(mensaje):
    print(pintar(f"  ℹ {mensaje}", AMARILLO))


# ---------- menús dinámicos ----------
def imprimir_menu(opciones, color=CIAN):
    """opciones = lista de (clave, texto, detalle). El menú se dibuja
    recorriendo la lista, así agregar una opción es agregar una tupla."""
    print()
    for clave, texto, detalle in opciones:
        tono = ROJO if clave == "0" else color
        marca = pintar(f"[{clave}]", NEGRITA, tono)
        extra = pintar(f"   {detalle}", TENUE) if detalle else ""
        print(f"  {marca} {texto}{extra}")
    print()


def pedir_opcion():
    return input(pintar("  ➤ Opción: ", NEGRITA, AMARILLO)).strip()


def pedir(texto):
    return input(pintar(f"  {texto}", CIAN))


def barra(valor, maximo, ancho=20):
    """Barra de progreso: verde si va bien, amarilla a medias, roja si es baja."""
    proporcion = 0 if maximo == 0 else max(0, min(1, valor / maximo))
    llenos = round(proporcion * ancho)
    tono = VERDE if proporcion >= 0.7 else AMARILLO if proporcion >= 0.5 else ROJO
    return pintar("█" * llenos, tono) + pintar("░" * (ancho - llenos), TENUE)


def confirmar(pregunta):
    respuesta = input(pintar(f"  {pregunta} (s/n): ", AMARILLO)).strip().lower()
    return respuesta == "s"
