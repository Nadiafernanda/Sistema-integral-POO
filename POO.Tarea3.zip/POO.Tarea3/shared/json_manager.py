import json
from pathlib import Path


class GestorJSON:
    """Único lugar del proyecto que sabe leer y escribir archivos JSON.
    Los controladores solo le piden la lista o le entregan la lista nueva."""

    def __init__(self, archivo):
        self.archivo = Path(archivo)

    def leer(self):
        # Si el archivo todavía no existe, nace vacío para que el programa no falle
        if not self.archivo.exists():
            self.guardar([])
        with self.archivo.open("r", encoding="utf-8") as f:
            return json.load(f)

    def guardar(self, datos):
        self.archivo.parent.mkdir(parents=True, exist_ok=True)
        with self.archivo.open("w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
